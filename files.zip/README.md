# 🦷 Residência Odonto — Central de Estudos

Repositório pessoal de estudo para provas de residência em Odontologia
(ENARE e processos seletivos como o da FDT). Materiais versionados,
acessíveis de qualquer lugar — inclusive do celular.

## Estrutura

```
residencia-odonto/
├── provas/         Provas em HTML interativo (responder + gabarito comentado)
├── gabaritos/      Gabaritos de referência rápida
├── plano/          Plano de estudos, método e checklist de temas do edital
└── progresso/      Como salvar/versionar seu progresso
```

## Como usar

1. **Responder** → abra o arquivo em `provas/` no navegador (funciona no celular).
   Toque na alternativa, confirme e leia o porquê da certa e das erradas.
2. **Registrar o erro** → todo erro vira uma linha no seu registro de erros
   (`plano/registro-de-erros.md`).
3. **Revisar** → siga a revisão espaçada do `plano/plano-estudos.md`.
4. **Cobrir o edital** → marque os temas no `plano/checklist-temas.md`.

## Provas disponíveis

| Prova | Banca | Questões | Arquivo |
|-------|-------|----------|---------|
| Residência Multiprofissional 2025 — Odontologia | FDT / Fundatec | 60 | [`provas/fdt-2025-odonto.html`](provas/fdt-2025-odonto.html) |

## Fluxo de trabalho no GitHub

- Materiais (provas, gabaritos, notas) → versionados aqui, editáveis de qualquer lugar.
- Progresso do quiz (respostas) → fica no navegador do celular; veja `progresso/como-salvar.md`.
- A cada sessão de estudo: edite o registro de erros, faça `commit` e `push`.
